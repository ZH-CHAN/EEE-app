package hk.hku.eee.hkueee.menuactivity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import hk.hku.eee.hkueee.R;

public class ProgrammeDescription extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_programme_description);

    }
}
